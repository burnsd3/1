---
applyTo: '**'
description: Workspace-specific AI memory for this project
lastOptimized: '2025-09-22T16:48:13.221599+00:00'
entryCount: 1
optimizationVersion: 1
autoOptimize: true
sizeThreshold: 50000
entryThreshold: 20
timeThreshold: 7
---
# Workspace AI Memory
This file contains workspace-specific information for AI conversations.

## Memories/Facts
- **2025-09-22 09:48:** The instructions.md file for the CAMERA APP project has been loaded. It contains detailed operational rules, anti-pattern prevention protocols, batch processing rules, and guidelines for agent script ecosystem and memory management.- **2025-09-22 09:48:** The CAMERA APP project follows strict rules for file regeneration, naming conventions, and batch processing. It emphasizes production-grade code, no patching or appending, and mandatory audits after every batch.
