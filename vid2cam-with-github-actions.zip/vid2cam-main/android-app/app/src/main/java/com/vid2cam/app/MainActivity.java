package com.vid2cam.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.media.Image;
import android.graphics.Color;
import android.view.MotionEvent;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "Vid2Cam";
    private static final int REQUEST_CAMERA_PERMISSION = 1;
    
    // Permission tracking
    private boolean mIsRequestingPermissions = false;
    
    // Camera components
    private CameraManager mCameraManager;
    private CameraDevice mCameraDevice;
    private CameraCaptureSession mCaptureSession;
    private ImageReader mImageReader;
    private CaptureRequest.Builder mPreviewRequestBuilder;
    private CaptureRequest mPreviewRequest;
    private String mCameraId;
    private Size mPreviewSize;
    
    // UI components
    private TextureView mTextureView;
    private Button mCaptureButton, mRecordButton, mSwitchCameraButton, mFlashButton, mOpenGLToggleButton;
    private Button mImageOverlayButton;
    private EditText mTextOverlayInput;
    private ImageView mImageOverlay;
    private TextView mTextOverlay;
    private Spinner mFilterSpinner;
    
    // Background thread
    private HandlerThread mBackgroundThread;
    private Handler mBackgroundHandler;
    
    // Camera states
    private boolean mIsUsingFrontCamera = false;
    private boolean mIsFlashOn = false;
    private boolean mIsRecordingVideo = false;
    private boolean mIsOpenGLEnabled = false;
    
    // Video recording
    private MediaRecorder mMediaRecorder;
    private String mNextVideoAbsolutePath;
    
    // OpenGL and overlay processing
    private VideoOverlayMuxer mVideoMuxer;
    private OpenGLPreviewRenderer mOpenGLRenderer;
    private static final int REQUEST_PICK_IMAGE = 1001;
    private static final int REQUEST_PICK_VIDEO = 1002;
    private Button mVideoOverlayButton;
    private SeekBar mOverlayOpacity;
    private float mLastTouchX, mLastTouchY;
    private static final String PREFS_NAME = "vid2cam_prefs";
    private static final String KEY_SELECTED_IMAGE_URI = "selected_image_uri";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "MainActivity onCreate started");
        
        setContentView(R.layout.activity_main);
        
        initializeViews();
        setupClickListeners();
        
        if (hasRequiredPermissions()) {
            initializeCamera();
        } else {
            requestPermissions();
        }
        
        // Debug: Log successful onCreate completion
        Log.d(TAG, "MainActivity onCreate completed successfully");
    }
    
    private void initializeViews() {
        mTextureView = findViewById(R.id.textureView);
        mCaptureButton = findViewById(R.id.captureButton);
    mImageOverlayButton = findViewById(R.id.imageOverlayButton);
        mRecordButton = findViewById(R.id.recordButton);
        mSwitchCameraButton = findViewById(R.id.switchCameraButton);
        mFlashButton = findViewById(R.id.flashButton);
        mOpenGLToggleButton = findViewById(R.id.openglToggleButton);
        mTextOverlayInput = findViewById(R.id.textOverlayInput);
        mImageOverlay = findViewById(R.id.imageOverlay);
        mTextOverlay = findViewById(R.id.textOverlay);
        mFilterSpinner = findViewById(R.id.filterSpinner);
    mVideoOverlayButton = findViewById(R.id.videoOverlayButton);
    mOverlayOpacity = findViewById(R.id.overlayOpacity);
        
        // Set up filter spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.filter_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mFilterSpinner.setAdapter(adapter);
    }
    
    private void setupClickListeners() {
        mCaptureButton.setOnClickListener(v -> captureImage());
        mRecordButton.setOnClickListener(v -> {
            if (mIsRecordingVideo) {
                stopRecordingVideo();
            } else {
                startRecordingVideo();
            }
        });
        mSwitchCameraButton.setOnClickListener(v -> switchCamera());
        mFlashButton.setOnClickListener(v -> toggleFlash());
        mOpenGLToggleButton.setOnClickListener(v -> toggleOpenGLPreview());
        
        mTextOverlayInput.setOnEditorActionListener((v, actionId, event) -> {
            String text = mTextOverlayInput.getText().toString();
            if (!text.isEmpty()) {
                mTextOverlay.setText(text);
                mTextOverlay.setVisibility(View.VISIBLE);
                // Sync overlays to muxer
                updateMuxerOverlays();
            }
            return true;
        });
        
    mFilterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Apply filter based on selection
                applyFilter(position);
            }
            
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Image overlay button (same behavior as tapping the overlay itself)
        mImageOverlayButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            startActivityForResult(Intent.createChooser(intent, "Select overlay image"), REQUEST_PICK_IMAGE);
        });

        // Video overlay selection button
        mVideoOverlayButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("video/*");
            startActivityForResult(Intent.createChooser(intent, "Select overlay video"), REQUEST_PICK_VIDEO);
        });

        // Overlay opacity control
        mOverlayOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                try {
                    if (mVideoMuxer != null) {
                        mVideoMuxer.setImageOverlayAlpha(progress);
                    }
                } catch (Exception ignored) {}
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Click image overlay to pick a new image; long-press toggles visibility
        mImageOverlay.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            startActivityForResult(Intent.createChooser(intent, "Select overlay image"), REQUEST_PICK_IMAGE);
        });
        mImageOverlay.setOnLongClickListener(v -> {
            if (mImageOverlay.getVisibility() == View.VISIBLE) {
                mImageOverlay.setVisibility(View.GONE);
            } else {
                mImageOverlay.setVisibility(View.VISIBLE);
            }
            updateMuxerOverlays();
            return true;
        });

        // Drag-to-move for image overlay
        mImageOverlay.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    mLastTouchX = event.getRawX();
                    mLastTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - mLastTouchX;
                    float dy = event.getRawY() - mLastTouchY;
                    v.setX(v.getX() + dx);
                    v.setY(v.getY() + dy);
                    mLastTouchX = event.getRawX();
                    mLastTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_UP:
                    updateMuxerOverlays();
                    return true;
            }
            return false;
        });

        // Drag-to-move and double-tap to toggle text size for text overlay
        mTextOverlay.setOnTouchListener(new View.OnTouchListener() {
            private long lastTapTime = 0;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        mLastTouchX = event.getRawX();
                        mLastTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - mLastTouchX;
                        float dy = event.getRawY() - mLastTouchY;
                        v.setX(v.getX() + dx);
                        v.setY(v.getY() + dy);
                        mLastTouchX = event.getRawX();
                        mLastTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        updateMuxerOverlays();
                        long now = System.currentTimeMillis();
                        if (now - lastTapTime < 300) {
                            // double-tap -> toggle size
                            float current = mTextOverlay.getTextSize();
                            mTextOverlay.setTextSize(current > 60 ? 48 : 72);
                            updateMuxerOverlays();
                        }
                        lastTapTime = now;
                        return true;
                }
                return false;
            }
        });
    }

    // Synchronize the current UI overlays with the VideoOverlayMuxer
    private void updateMuxerOverlays() {
        if (mVideoMuxer == null) return;

        // Clear existing overlays in muxer and re-add current UI overlays
        mVideoMuxer.clearOverlays();

        // Add text overlay if present and visible
        try {
            String text = (mTextOverlay != null) ? mTextOverlay.getText().toString() : "";
            if (!text.isEmpty() && mTextOverlay.getVisibility() == View.VISIBLE) {
                float[] coords = mapViewCenterToVideoCoords(mTextOverlay);
                mVideoMuxer.addTextOverlay(text, coords[0], coords[1]);
            }

            // Add image overlay if visible
            if (mImageOverlay != null && mImageOverlay.getVisibility() == View.VISIBLE && mImageOverlay.getDrawable() != null) {
                float[] coords = mapViewCenterToVideoCoords(mImageOverlay);
                mVideoMuxer.addImageOverlay(mImageOverlay.getDrawable(), coords[0], coords[1]);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating muxer overlays", e);
        }
    }

    // Map a view's center position to video pixel coordinates
    private float[] mapViewCenterToVideoCoords(View overlayView) {
        float[] out = new float[]{50.0f, 100.0f};
        try {
            if (mPreviewSize == null || mTextureView == null) return out;

            float viewCenterX = overlayView.getX() + (overlayView.getWidth() / 2.0f);
            float viewCenterY = overlayView.getY() + (overlayView.getHeight() / 2.0f);

            float relX = viewCenterX / (float) Math.max(1, mTextureView.getWidth());
            float relY = viewCenterY / (float) Math.max(1, mTextureView.getHeight());

            float videoX = relX * mPreviewSize.getWidth();
            float videoY = relY * mPreviewSize.getHeight();
            out[0] = videoX;
            out[1] = videoY;
        } catch (Exception e) {
            Log.e(TAG, "Error mapping view to video coords", e);
        }
        return out;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    mImageOverlay.setImageURI(uri);
                    mImageOverlay.setVisibility(View.VISIBLE);
                    updateMuxerOverlays();
                } catch (Exception e) {
                    Log.e(TAG, "Error loading picked image", e);
                }
            }
        } else if (requestCode == REQUEST_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    // Pass selected video Uri to muxer for later compositing
                    if (mVideoMuxer != null) {
                        mVideoMuxer.setSelectedVideoUri(uri);
                    }
                    Toast.makeText(this, "Video overlay selected", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Log.e(TAG, "Error setting picked video", e);
                }
            }
        }
    }
    
    private boolean hasRequiredPermissions() {
        boolean cameraGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean audioGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        
        Log.d(TAG, "Permission check - Camera: " + cameraGranted + ", Audio: " + audioGranted);
        return cameraGranted && audioGranted;
    }
    
    private void requestPermissions() {
        if (mIsRequestingPermissions) {
            Log.d(TAG, "Already requesting permissions, skipping duplicate request");
            return;
        }
        
        Log.d(TAG, "Requesting essential camera permissions...");
        mIsRequestingPermissions = true;
        
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
        }, REQUEST_CAMERA_PERMISSION);
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.d(TAG, "Permission result received for request: " + requestCode);
        
        mIsRequestingPermissions = false; // Reset the flag
        
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (hasRequiredPermissions()) {
                Log.d(TAG, "All permissions granted - initializing camera");
                initializeCamera();
                Toast.makeText(this, "Permissions granted! Initializing camera...", Toast.LENGTH_SHORT).show();
            } else {
                Log.e(TAG, "Required permissions denied");
                Toast.makeText(this, "Camera and audio permissions are required", Toast.LENGTH_LONG).show();
                // Don't request again immediately to avoid infinite loop
            }
        }
    }
    
    private void initializeCamera() {
        mCameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        startBackgroundThread();
        openCamera();
        initializeOpenGLPipeline();
        // Initialize overlay muxer
        if (mVideoMuxer == null) {
            mVideoMuxer = new VideoOverlayMuxer();
        }
        Log.d(TAG, "Camera initialization completed");
    }
    
    private void openCamera() {
        try {
            mCameraId = mIsUsingFrontCamera ? getFrontCameraId() : getBackCameraId();
            if (mCameraId == null) {
                Toast.makeText(this, "No camera available", Toast.LENGTH_SHORT).show();
                return;
            }
            
            CameraCharacteristics characteristics = mCameraManager.getCameraCharacteristics(mCameraId);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                mPreviewSize = chooseOptimalSize(map.getOutputSizes(SurfaceTexture.class), 1920, 1080);
            }
            
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            
            mCameraManager.openCamera(mCameraId, mStateCallback, mBackgroundHandler);
            
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error opening camera", e);
        }
    }
    
    private void closeCamera() {
        if (mCaptureSession != null) {
            mCaptureSession.close();
            mCaptureSession = null;
        }
        if (mCameraDevice != null) {
            mCameraDevice.close();
            mCameraDevice = null;
        }
        if (mImageReader != null) {
            mImageReader.close();
            mImageReader = null;
        }
    }
    
    private String getBackCameraId() {
        try {
            for (String cameraId : mCameraManager.getCameraIdList()) {
                CameraCharacteristics characteristics = mCameraManager.getCameraCharacteristics(cameraId);
                if (characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK) {
                    return cameraId;
                }
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error getting back camera ID", e);
        }
        return null;
    }
    
    private String getFrontCameraId() {
        try {
            for (String cameraId : mCameraManager.getCameraIdList()) {
                CameraCharacteristics characteristics = mCameraManager.getCameraCharacteristics(cameraId);
                if (characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT) {
                    return cameraId;
                }
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error getting front camera ID", e);
        }
        return null;
    }
    
    private Size chooseOptimalSize(Size[] choices, int textureViewWidth, int textureViewHeight) {
        if (choices == null || choices.length == 0) {
            return new Size(640, 480);
        }
        
        for (Size size : choices) {
            if (size.getWidth() <= textureViewWidth && size.getHeight() <= textureViewHeight) {
                return size;
            }
        }
        return choices[0];
    }
    
    private void startBackgroundThread() {
        if (mBackgroundThread == null) {
            mBackgroundThread = new HandlerThread("CameraBackground");
            mBackgroundThread.start();
            mBackgroundHandler = new Handler(mBackgroundThread.getLooper());
        }
    }
    
    private void stopBackgroundThread() {
        if (mBackgroundThread != null) {
            mBackgroundThread.quitSafely();
            try {
                mBackgroundThread.join();
                mBackgroundThread = null;
                mBackgroundHandler = null;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    private final CameraDevice.StateCallback mStateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice cameraDevice) {
            mCameraDevice = cameraDevice;
            createCameraPreviewSession();
        }
        
        @Override
        public void onDisconnected(@NonNull CameraDevice cameraDevice) {
            cameraDevice.close();
            mCameraDevice = null;
        }
        
        @Override
        public void onError(@NonNull CameraDevice cameraDevice, int error) {
            cameraDevice.close();
            mCameraDevice = null;
        }
    };
    
    private void createCameraPreviewSession() {
        try {
            SurfaceTexture texture = mTextureView.getSurfaceTexture();
            if (texture == null) {
                return;
            }
            
            texture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
            Surface surface = new Surface(texture);
            
            mPreviewRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            mPreviewRequestBuilder.addTarget(surface);

            // If overlay muxer is recording, ensure its input surface is added
            try {
                if (mVideoMuxer != null && mVideoMuxer.isRecording() && mVideoMuxer.getInputSurface() != null) {
                    mPreviewRequestBuilder.addTarget(mVideoMuxer.getInputSurface());
                }
            } catch (Exception ignored) {}
            
            mCameraDevice.createCaptureSession(Arrays.asList(surface), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                    if (mCameraDevice == null) {
                        return;
                    }
                    
                    mCaptureSession = cameraCaptureSession;
                    try {
                        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                        mPreviewRequest = mPreviewRequestBuilder.build();

                        mCaptureSession.setRepeatingRequest(mPreviewRequest, new CameraCaptureSession.CaptureCallback() {
                            @Override
                            public void onCaptureCompleted(@NonNull CameraCaptureSession session,
                                                           @NonNull CaptureRequest request,
                                                           @NonNull TotalCaptureResult result) {
                                super.onCaptureCompleted(session, request, result);
                                // If overlay muxer is active, process a quick bitmap copy
                                if (mVideoMuxer != null && mVideoMuxer.isRecording()) {
                                    try {
                                        Bitmap frame = mTextureView.getBitmap();
                                        if (frame != null) {
                                            mVideoMuxer.processFrame(frame);
                                            frame.recycle();
                                        }
                                    } catch (Exception e) {
                                        Log.e(TAG, "Error capturing preview frame for overlay processing", e);
                                    }
                                }
                            }
                        }, mBackgroundHandler);
                    } catch (CameraAccessException e) {
                        Log.e(TAG, "Error creating camera preview session", e);
                    }
                }
                
                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                    Toast.makeText(MainActivity.this, "Failed to configure camera", Toast.LENGTH_SHORT).show();
                }
            }, null);
            
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error creating camera preview session", e);
        }
    }
    
    private void captureImage() {
        if (mCameraDevice == null) {
            return;
        }
        
        try {
            final ImageReader reader = ImageReader.newInstance(mPreviewSize.getWidth(), mPreviewSize.getHeight(),
                    ImageFormat.JPEG, 1);
            
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    Image image = null;
                    try {
                        image = reader.acquireLatestImage();
                        ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                        byte[] bytes = new byte[buffer.remaining()];
                        buffer.get(bytes);
                        saveImage(bytes);
                    } finally {
                        if (image != null) {
                            image.close();
                        }
                    }
                }
            }, mBackgroundHandler);
            
            final CaptureRequest.Builder captureBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(reader.getSurface());
            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            
            CameraCaptureSession.CaptureCallback captureCallback = new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(@NonNull CameraCaptureSession session,
                                               @NonNull CaptureRequest request,
                                               @NonNull TotalCaptureResult result) {
                    super.onCaptureCompleted(session, request, result);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Image captured!", Toast.LENGTH_SHORT).show());
                }
            };
            
            mCaptureSession.capture(captureBuilder.build(), captureCallback, mBackgroundHandler);
            
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error capturing image", e);
        }
    }
    
    private void saveImage(byte[] bytes) {
        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            String fileName = "VID2CAM_" + timeStamp + ".jpg";
            File file = new File(getExternalFilesDir(null), fileName);
            
            FileOutputStream output = new FileOutputStream(file);
            output.write(bytes);
            output.close();
            
            Log.d(TAG, "Image saved: " + file.getAbsolutePath());
        } catch (IOException e) {
            Log.e(TAG, "Error saving image", e);
        }
    }
    
    private void startRecordingVideo() {
        if (mIsRecordingVideo) {
            return;
        }
        
        Log.d(TAG, "Starting video recording");
        mIsRecordingVideo = true;
        mRecordButton.setText("Stop Recording");
        
        // Start overlay muxer recording if available
        try {
            String path = new File(getExternalFilesDir(null), "vid2cam_" + System.currentTimeMillis() + ".mp4").getAbsolutePath();
            if (mVideoMuxer != null && !mVideoMuxer.isRecording()) {
                mVideoMuxer.startRecording(path, mPreviewSize.getWidth(), mPreviewSize.getHeight());
                // Recreate preview session so camera output also goes to muxer's input surface
                createCameraPreviewSession();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error starting overlay muxer", e);
        }

        // Update UI state during recording
        try {
            mRecordButton.setBackgroundColor(Color.RED);
            mCaptureButton.setEnabled(false);
            mSwitchCameraButton.setEnabled(false);
        } catch (Exception ignored) {}

        Toast.makeText(this, "Video recording started", Toast.LENGTH_SHORT).show();
    }
    
    private void stopRecordingVideo() {
        if (!mIsRecordingVideo) {
            return;
        }
        
        Log.d(TAG, "Stopping video recording");
        mIsRecordingVideo = false;
        mRecordButton.setText("Record Video");
        
        // Stop overlay muxer recording if available
        try {
            if (mVideoMuxer != null && mVideoMuxer.isRecording()) {
                mVideoMuxer.stopRecording();
                // Recreate preview session to remove muxer surface from targets
                createCameraPreviewSession();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error stopping overlay muxer", e);
        }

        // Restore UI state
        try {
            mRecordButton.setBackgroundColor(Color.LTGRAY);
            mCaptureButton.setEnabled(true);
            mSwitchCameraButton.setEnabled(true);
        } catch (Exception ignored) {}

        Toast.makeText(this, "Video recording stopped", Toast.LENGTH_SHORT).show();
    }
    
    private void switchCamera() {
        closeCamera();
        mIsUsingFrontCamera = !mIsUsingFrontCamera;
        openCamera();
        Log.d(TAG, "Switched to " + (mIsUsingFrontCamera ? "front" : "back") + " camera");
    }
    
    private void toggleFlash() {
        mIsFlashOn = !mIsFlashOn;
        mFlashButton.setText(mIsFlashOn ? "Flash Off" : "Flash On");
        
        if (mPreviewRequestBuilder != null) {
            try {
                mPreviewRequestBuilder.set(CaptureRequest.FLASH_MODE, 
                    mIsFlashOn ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
                mCaptureSession.setRepeatingRequest(mPreviewRequestBuilder.build(), null, mBackgroundHandler);
            } catch (CameraAccessException e) {
                Log.e(TAG, "Error toggling flash", e);
            }
        }
    }
    
    private void toggleOpenGLPreview() {
        mIsOpenGLEnabled = !mIsOpenGLEnabled;
        mOpenGLToggleButton.setText(mIsOpenGLEnabled ? "Disable OpenGL" : "Enable OpenGL");
        
        if (mIsOpenGLEnabled) {
            initializeOpenGLPipeline();
        }
        
        Log.d(TAG, "OpenGL preview " + (mIsOpenGLEnabled ? "enabled" : "disabled"));
    }
    
    private void initializeOpenGLPipeline() {
        try {
            if (mOpenGLRenderer == null) {
                mOpenGLRenderer = new OpenGLPreviewRenderer();
            }
            Log.d(TAG, "OpenGL pipeline initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize OpenGL pipeline", e);
            Toast.makeText(this, "OpenGL initialization failed", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void applyFilter(int filterIndex) {
        Log.d(TAG, "Applying filter: " + filterIndex);
        // Filter application logic would go here
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume called - checking permissions and camera state");
        
        startBackgroundThread();
        
        if (hasRequiredPermissions()) {
            Log.d(TAG, "Permissions granted - checking camera state");
            if (mTextureView.isAvailable()) {
                openCamera();
            } else {
                mTextureView.setSurfaceTextureListener(mSurfaceTextureListener);
            }
        } else if (!mIsRequestingPermissions) {
            Log.d(TAG, "Permissions not granted - requesting permissions");
            requestPermissions();
        } else {
            Log.d(TAG, "Permission request already in progress, waiting...");
        }
    }
    
    @Override
    protected void onPause() {
        closeCamera();
        stopBackgroundThread();
        super.onPause();
    }
    
    @Override
    protected void onDestroy() {
        if (mOpenGLRenderer != null) {
            mOpenGLRenderer.release();
        }
        super.onDestroy();
    }
    
    private final TextureView.SurfaceTextureListener mSurfaceTextureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            openCamera();
        }
        
        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {}
        
        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return true;
        }
        
        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {}
    };
}
