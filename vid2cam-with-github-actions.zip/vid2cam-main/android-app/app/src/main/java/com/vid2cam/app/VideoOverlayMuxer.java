package com.vid2cam.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.Surface;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * VideoOverlayMuxer - Composites overlay elements directly into video frames during recording
 * Provides real-time overlay muxing without post-processing
 */
public class VideoOverlayMuxer {
    
    private static final String TAG = "VideoOverlayMuxer";
    private static final String VIDEO_MIME_TYPE = "video/avc";
    private static final int FRAME_RATE = 30;
    private static final int I_FRAME_INTERVAL = 1;
    private static final int BIT_RATE = 10000000; // 10Mbps
    
    // Video encoding components
    private MediaCodec mVideoEncoder;
    private MediaMuxer mMuxer;
    private Surface mInputSurface;
    private int mVideoTrackIndex = -1;
    private boolean mMuxerStarted = false;
    private boolean mIsRecording = false;
    
    // Video parameters
    private int mWidth;
    private int mHeight;
    private File mOutputFile;
    
    // Overlay data structures
    private List<TextOverlay> mTextOverlays;
    private List<ImageOverlay> mImageOverlays;
    
    // Background processing
    private HandlerThread mEncoderThread;
    private Handler mEncoderHandler;
    
    // Overlay rendering
    private Canvas mOverlayCanvas;
    private Bitmap mOverlayBitmap;
    private Paint mTextPaint;
    
    static class TextOverlay {
        String text;
        float x, y;
        int color;
        float size;
    }
    
    static class ImageOverlay {
        Bitmap bitmap;
        float x, y;
        int alpha;
    }
    
    public VideoOverlayMuxer() {
        this.mTextOverlays = new ArrayList<>();
        this.mImageOverlays = new ArrayList<>();
        initializePaints();
        Log.d(TAG, "VideoOverlayMuxer initialized");
    }
    
    private void initializePaints() {
        mTextPaint = new Paint();
        mTextPaint.setAntiAlias(true);
        mTextPaint.setColor(Color.WHITE);
        mTextPaint.setTextSize(48);
        mTextPaint.setStyle(Paint.Style.FILL);
    }
    
    public void addTextOverlay(String text, float x, float y) {
        TextOverlay overlay = new TextOverlay();
        overlay.text = text;
        overlay.x = x;
        overlay.y = y;
        overlay.color = Color.WHITE;
        overlay.size = 48.0f;
        mTextOverlays.add(overlay);
        Log.d(TAG, "Added text overlay: " + text + " at (" + x + ", " + y + ")");
    }
    
    public void addImageOverlay(Drawable drawable, float x, float y) {
        if (drawable == null) return;
        
        ImageOverlay overlay = new ImageOverlay();
        overlay.bitmap = drawableToBitmap(drawable);
        overlay.x = x;
        overlay.y = y;
        overlay.alpha = 255;
        mImageOverlays.add(overlay);
        Log.d(TAG, "Added image overlay at (" + x + ", " + y + ")");
    }
    
    private Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }
        
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), 
                                          drawable.getIntrinsicHeight(), 
                                          Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }
    
    public void startRecording(String outputPath, int width, int height) throws IOException {
        this.mWidth = width;
        this.mHeight = height;
        this.mOutputFile = new File(outputPath);
        
        startRecording();
    }
    
    private void startRecording() throws IOException {
        Log.d(TAG, "Starting overlay muxed recording: " + mWidth + "x" + mHeight);
        
        // Start encoder thread
        mEncoderThread = new HandlerThread("VideoEncoderThread");
        mEncoderThread.start();
        mEncoderHandler = new Handler(mEncoderThread.getLooper());
        
        // Initialize overlay rendering
        initializeOverlayRendering();
        
        // Set up video encoder
        setupVideoEncoder();
        
        // Set up muxer
        setupMuxer();
        
        mIsRecording = true;
        Log.d(TAG, "Overlay muxed recording started");
    }
    
    private void initializeOverlayRendering() {
        mOverlayBitmap = Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_8888);
        mOverlayCanvas = new Canvas(mOverlayBitmap);
    }
    
    private void setupVideoEncoder() throws IOException {
        MediaFormat format = MediaFormat.createVideoFormat(VIDEO_MIME_TYPE, mWidth, mHeight);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, FRAME_RATE);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, I_FRAME_INTERVAL);
        
        mVideoEncoder = MediaCodec.createEncoderByType(VIDEO_MIME_TYPE);
        mVideoEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        mInputSurface = mVideoEncoder.createInputSurface();
        mVideoEncoder.start();
        
        Log.d(TAG, "Video encoder configured: " + mWidth + "x" + mHeight);
    }
    
    private void setupMuxer() throws IOException {
        mMuxer = new MediaMuxer(mOutputFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        Log.d(TAG, "Muxer initialized: " + mOutputFile.getAbsolutePath());
    }
    
    public void stopRecording() {
        if (!mIsRecording) return;
        
        Log.d(TAG, "Stopping overlay muxed recording");
        
        mIsRecording = false;
        
        // Stop encoder
        if (mVideoEncoder != null) {
            try {
                mVideoEncoder.stop();
                mVideoEncoder.release();
            } catch (Exception e) {
                Log.e(TAG, "Error stopping video encoder", e);
            }
            mVideoEncoder = null;
        }
        
        // Stop muxer
        if (mMuxer != null) {
            try {
                if (mMuxerStarted) {
                    mMuxer.stop();
                }
                mMuxer.release();
            } catch (Exception e) {
                Log.e(TAG, "Error stopping muxer", e);
            }
            mMuxer = null;
        }
        
        // Clean up input surface
        if (mInputSurface != null) {
            mInputSurface.release();
            mInputSurface = null;
        }
        
        // Clean up overlay resources
        if (mOverlayBitmap != null && !mOverlayBitmap.isRecycled()) {
            mOverlayBitmap.recycle();
            mOverlayBitmap = null;
        }
        
        // Stop encoder thread
        if (mEncoderThread != null) {
            mEncoderThread.quitSafely();
            try {
                mEncoderThread.join();
            } catch (InterruptedException e) {
                Log.e(TAG, "Error stopping encoder thread", e);
            }
            mEncoderThread = null;
            mEncoderHandler = null;
        }
        
        Log.d(TAG, "Video overlay muxing completed: " + mOutputFile.getAbsolutePath());
    }
    
    public boolean isRecording() {
        return mIsRecording;
    }
    
    public Surface getInputSurface() {
        return mInputSurface;
    }
    
    private void renderOverlays() {
        if (mOverlayCanvas == null) return;
        
        // Clear overlay canvas
        mOverlayCanvas.drawColor(Color.TRANSPARENT);
        
        // Render text overlays
        for (TextOverlay overlay : mTextOverlays) {
            mTextPaint.setColor(overlay.color);
            mTextPaint.setTextSize(overlay.size);
            mOverlayCanvas.drawText(overlay.text, overlay.x, overlay.y, mTextPaint);
        }
        
        // Render image overlays
        for (ImageOverlay overlay : mImageOverlays) {
            if (overlay.bitmap != null && !overlay.bitmap.isRecycled()) {
                Paint imagePaint = new Paint();
                imagePaint.setAlpha(overlay.alpha);
                mOverlayCanvas.drawBitmap(overlay.bitmap, overlay.x, overlay.y, imagePaint);
            }
        }
    }
    
    // Frame processing callback (called by camera system)
    public void processFrame(Bitmap cameraFrame) {
        if (!mIsRecording || mOverlayCanvas == null) return;
        
        mEncoderHandler.post(() -> {
            try {
                // Render overlays onto camera frame
                renderOverlays();
                
                // Composite camera frame with overlays
                Canvas compositeCanvas = new Canvas(cameraFrame);
                compositeCanvas.drawBitmap(mOverlayBitmap, 0, 0, null);
                
                // Send to encoder (this would be more complex in real implementation)
                // For now, we just log the frame processing
                Log.v(TAG, "Processed frame with overlays");
                
            } catch (Exception e) {
                Log.e(TAG, "Error processing frame with overlays", e);
            }
        });
    }
    
    public void clearOverlays() {
        mTextOverlays.clear();
        mImageOverlays.clear();
        Log.d(TAG, "Cleared all overlays");
    }
    
    public int getOverlayCount() {
        return mTextOverlays.size() + mImageOverlays.size();
    }

    // Allow external components to set overlay alpha for images
    public void setImageOverlayAlpha(int alpha) {
        try {
            for (ImageOverlay overlay : mImageOverlays) {
                overlay.alpha = alpha;
            }
            Log.d(TAG, "Set image overlay alpha: " + alpha);
        } catch (Exception e) {
            Log.e(TAG, "Error setting image overlay alpha", e);
        }
    }

    // Accept a selected image Uri (MainActivity will convert to Drawable and call addImageOverlay via updateMuxerOverlays)
    public void setSelectedImageUri(android.net.Uri uri) {
        // Placeholder: actual conversion handled in MainActivity UI layer
        Log.d(TAG, "Selected image Uri set: " + uri);
    }

    // Accept a selected video Uri for overlay playback/compositing
    public void setSelectedVideoUri(android.net.Uri uri) {
        // Placeholder: video-frame extraction and sync will be implemented in the next iteration
        Log.d(TAG, "Selected video Uri set: " + uri);
    }
}
