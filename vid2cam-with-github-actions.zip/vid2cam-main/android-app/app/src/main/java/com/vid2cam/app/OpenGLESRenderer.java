package com.vid2cam.app;

import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * OpenGL ES Renderer for real-time camera effects and AI model pipeline
 * Handles GPU-accelerated filters, overlays, and neural network integration
 */
public class OpenGLESRenderer implements GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {
    
    private static final String TAG = "OpenGLESRenderer";
    
    // Shader programs
    private static final String VERTEX_SHADER = 
        "uniform mat4 uMVPMatrix;" +
        "attribute vec4 vPosition;" +
        "attribute vec2 aTextureCoord;" +
        "varying vec2 vTextureCoord;" +
        "void main() {" +
        "  gl_Position = uMVPMatrix * vPosition;" +
        "  vTextureCoord = aTextureCoord;" +
        "}";
    
    private static final String FRAGMENT_SHADER = 
        "#extension GL_OES_EGL_image_external : require\n" +
        "precision mediump float;" +
        "varying vec2 vTextureCoord;" +
        "uniform samplerExternalOES sTexture;" +
        "uniform float uBrightness;" +
        "uniform float uContrast;" +
        "uniform float uSaturation;" +
        "void main() {" +
        "  vec4 color = texture2D(sTexture, vTextureCoord);" +
        "  // Apply brightness" +
        "  color.rgb += uBrightness;" +
        "  // Apply contrast" +
        "  color.rgb = ((color.rgb - 0.5) * uContrast) + 0.5;" +
        "  // Apply saturation" +
        "  float gray = dot(color.rgb, vec3(0.299, 0.587, 0.114));" +
        "  color.rgb = mix(vec3(gray), color.rgb, uSaturation);" +
        "  gl_FragColor = color;" +
        "}";
    
    // Edge detection filter for AI preprocessing
    private static final String EDGE_DETECTION_FRAGMENT_SHADER = 
        "#extension GL_OES_EGL_image_external : require\n" +
        "precision mediump float;" +
        "varying vec2 vTextureCoord;" +
        "uniform samplerExternalOES sTexture;" +
        "uniform vec2 uTexelSize;" +
        "void main() {" +
        "  vec4 center = texture2D(sTexture, vTextureCoord);" +
        "  vec4 left = texture2D(sTexture, vTextureCoord - vec2(uTexelSize.x, 0.0));" +
        "  vec4 right = texture2D(sTexture, vTextureCoord + vec2(uTexelSize.x, 0.0));" +
        "  vec4 up = texture2D(sTexture, vTextureCoord - vec2(0.0, uTexelSize.y));" +
        "  vec4 down = texture2D(sTexture, vTextureCoord + vec2(0.0, uTexelSize.y));" +
        "  vec4 edge = abs(center - left) + abs(center - right) + abs(center - up) + abs(center - down);" +
        "  gl_FragColor = vec4(edge.rgb, 1.0);" +
        "}";
    
    // Matrix and buffers
    private final float[] mMVPMatrix = new float[16];
    private final float[] mProjectionMatrix = new float[16];
    private final float[] mViewMatrix = new float[16];
    
    // OpenGL objects
    private int mProgram;
    private int mEdgeProgram;
    private int mTextureID;
    private SurfaceTexture mSurfaceTexture;
    private FloatBuffer mVertexBuffer;
    private FloatBuffer mTextureBuffer;
    
    // Shader handles
    private int mPositionHandle;
    private int mTextureCoordHandle;
    private int mMVPMatrixHandle;
    private int mTextureHandle;
    private int mBrightnessHandle;
    private int mContrastHandle;
    private int mSaturationHandle;
    
    // Filter parameters
    private float mBrightness = 0.0f;
    private float mContrast = 1.0f;
    private float mSaturation = 1.0f;
    private boolean mUpdateSurface = false;
    private boolean mUseEdgeDetection = false;
    
    // Vertex coordinates for full-screen quad
    private static final float[] SQUARE_COORDS = {
        -1.0f, -1.0f,
         1.0f, -1.0f,
        -1.0f,  1.0f,
         1.0f,  1.0f,
    };
    
    // Texture coordinates
    private static final float[] TEXTURE_COORDS = {
        0.0f, 1.0f,
        1.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
    };
    
    // Callback interface for AI model integration
    public interface FrameCallback {
        void onFrameAvailable(byte[] frameData, int width, int height);
    }
    
    private FrameCallback mFrameCallback;
    
    public OpenGLESRenderer() {
        // Initialize vertex buffer
        ByteBuffer bb = ByteBuffer.allocateDirect(SQUARE_COORDS.length * 4);
        bb.order(ByteOrder.nativeOrder());
        mVertexBuffer = bb.asFloatBuffer();
        mVertexBuffer.put(SQUARE_COORDS);
        mVertexBuffer.position(0);
        
        // Initialize texture buffer
        bb = ByteBuffer.allocateDirect(TEXTURE_COORDS.length * 4);
        bb.order(ByteOrder.nativeOrder());
        mTextureBuffer = bb.asFloatBuffer();
        mTextureBuffer.put(TEXTURE_COORDS);
        mTextureBuffer.position(0);
    }
    
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        
        // Load shaders and create program
        mProgram = createProgram(VERTEX_SHADER, FRAGMENT_SHADER);
        mEdgeProgram = createProgram(VERTEX_SHADER, EDGE_DETECTION_FRAGMENT_SHADER);
        
        if (mProgram == 0 || mEdgeProgram == 0) {
            Log.e(TAG, "Failed to create shader programs");
            return;
        }
        
        // Get shader handles
        mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
        mTextureCoordHandle = GLES20.glGetAttribLocation(mProgram, "aTextureCoord");
        mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        mTextureHandle = GLES20.glGetUniformLocation(mProgram, "sTexture");
        mBrightnessHandle = GLES20.glGetUniformLocation(mProgram, "uBrightness");
        mContrastHandle = GLES20.glGetUniformLocation(mProgram, "uContrast");
        mSaturationHandle = GLES20.glGetUniformLocation(mProgram, "uSaturation");
        
        // Create camera texture
        int[] textures = new int[1];
        GLES20.glGenTextures(1, textures, 0);
        mTextureID = textures[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTextureID);
        GLES20.glTexParameterf(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameterf(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        
        // Create surface texture
        mSurfaceTexture = new SurfaceTexture(mTextureID);
        mSurfaceTexture.setOnFrameAvailableListener(this);
        
        Log.d(TAG, "OpenGL ES surface created successfully");
    }
    
    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        
        float ratio = (float) width / height;
        Matrix.frustumM(mProjectionMatrix, 0, -ratio, ratio, -1, 1, 3, 7);
        Matrix.setLookAtM(mViewMatrix, 0, 0, 0, -3, 0f, 0f, 0f, 0f, 1.0f, 0.0f);
        Matrix.multiplyMM(mMVPMatrix, 0, mProjectionMatrix, 0, mViewMatrix, 0);
        
        Log.d(TAG, "Surface changed: " + width + "x" + height);
    }
    
    @Override
    public void onDrawFrame(GL10 gl) {
        synchronized(this) {
            if (mUpdateSurface) {
                mSurfaceTexture.updateTexImage();
                mUpdateSurface = false;
                
                // Extract frame data for AI model if callback is set
                if (mFrameCallback != null) {
                    extractFrameData();
                }
            }
        }
        
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        
        // Choose shader program based on filter mode
        int program = mUseEdgeDetection ? mEdgeProgram : mProgram;
        GLES20.glUseProgram(program);
        
        // Set vertex attributes
        GLES20.glEnableVertexAttribArray(mPositionHandle);
        GLES20.glVertexAttribPointer(mPositionHandle, 2, GLES20.GL_FLOAT, false, 0, mVertexBuffer);
        
        GLES20.glEnableVertexAttribArray(mTextureCoordHandle);
        GLES20.glVertexAttribPointer(mTextureCoordHandle, 2, GLES20.GL_FLOAT, false, 0, mTextureBuffer);
        
        // Set uniforms
        GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mMVPMatrix, 0);
        
        if (!mUseEdgeDetection) {
            GLES20.glUniform1f(mBrightnessHandle, mBrightness);
            GLES20.glUniform1f(mContrastHandle, mContrast);
            GLES20.glUniform1f(mSaturationHandle, mSaturation);
        }
        
        // Bind texture
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTextureID);
        GLES20.glUniform1i(mTextureHandle, 0);
        
        // Draw
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        
        // Disable vertex arrays
        GLES20.glDisableVertexAttribArray(mPositionHandle);
        GLES20.glDisableVertexAttribArray(mTextureCoordHandle);
    }
    
    @Override
    public synchronized void onFrameAvailable(SurfaceTexture surface) {
        mUpdateSurface = true;
    }
    
    public SurfaceTexture getSurfaceTexture() {
        return mSurfaceTexture;
    }
    
    // Filter controls for real-time adjustment
    public void setBrightness(float brightness) {
        mBrightness = Math.max(-1.0f, Math.min(1.0f, brightness));
    }
    
    public void setContrast(float contrast) {
        mContrast = Math.max(0.0f, Math.min(2.0f, contrast));
    }
    
    public void setSaturation(float saturation) {
        mSaturation = Math.max(0.0f, Math.min(2.0f, saturation));
    }
    
    public void setEdgeDetection(boolean enabled) {
        mUseEdgeDetection = enabled;
    }
    
    // AI model integration
    public void setFrameCallback(FrameCallback callback) {
        mFrameCallback = callback;
    }
    
    private void extractFrameData() {
        // TODO: Extract pixel data from current frame for AI model processing
        // This will be used for real-time object detection, face recognition, etc.
        Log.d(TAG, "Frame data extraction for AI model (pending implementation)");
    }
    
    // Shader utilities
    private int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        
        int[] compiled = new int[1];
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0);
        if (compiled[0] == 0) {
            Log.e(TAG, "Shader compilation failed: " + GLES20.glGetShaderInfoLog(shader));
            GLES20.glDeleteShader(shader);
            return 0;
        }
        
        return shader;
    }
    
    private int createProgram(String vertexSource, String fragmentSource) {
        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSource);
        if (vertexShader == 0) return 0;
        
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource);
        if (fragmentShader == 0) return 0;
        
        int program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vertexShader);
        GLES20.glAttachShader(program, fragmentShader);
        GLES20.glLinkProgram(program);
        
        int[] linkStatus = new int[1];
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0);
        if (linkStatus[0] != GLES20.GL_TRUE) {
            Log.e(TAG, "Program linking failed: " + GLES20.glGetProgramInfoLog(program));
            GLES20.glDeleteProgram(program);
            return 0;
        }
        
        return program;
    }
    
    public void release() {
        if (mSurfaceTexture != null) {
            mSurfaceTexture.release();
            mSurfaceTexture = null;
        }
        
        if (mProgram != 0) {
            GLES20.glDeleteProgram(mProgram);
            mProgram = 0;
        }
        
        if (mEdgeProgram != 0) {
            GLES20.glDeleteProgram(mEdgeProgram);
            mEdgeProgram = 0;
        }
        
        Log.d(TAG, "OpenGL ES renderer released");
    }
}