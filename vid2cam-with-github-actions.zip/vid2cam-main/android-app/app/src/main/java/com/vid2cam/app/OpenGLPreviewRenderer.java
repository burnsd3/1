package com.vid2cam.app;

import android.opengl.GLES20;
import android.util.Log;

public class OpenGLPreviewRenderer {
    private static final String TAG = "OpenGLRenderer";
    
    private boolean mInitialized = false;
    
    public OpenGLPreviewRenderer() {
        initialize();
    }
    
    private void initialize() {
        try {
            // Basic OpenGL ES 2.0 initialization
            Log.d(TAG, "Initializing OpenGL ES 2.0 renderer");
            mInitialized = true;
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize OpenGL renderer", e);
            mInitialized = false;
        }
    }
    
    public void release() {
        if (mInitialized) {
            Log.d(TAG, "Releasing OpenGL renderer resources");
            mInitialized = false;
        }
    }
    
    public boolean isInitialized() {
        return mInitialized;
    }
}
