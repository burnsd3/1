package com.vid2cam.app;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class CameraFilterRenderer implements GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {
    private SurfaceTexture cameraTexture;
    private int filterType = 0; // 0: None, 1: Sepia, 2: B&W, 3: Invert
    private final float[] mSTMatrix = new float[16];
    private boolean updateSurface = false;
    private int textureId;
    private Context context;

    public CameraFilterRenderer(Context context) {
        this.context = context;
    }

    public void setFilterType(int type) {
        filterType = type;
    }

    public SurfaceTexture getCameraTexture() {
        return cameraTexture;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        textureId = GLUtil.createOESTextureObject();
        cameraTexture = new SurfaceTexture(textureId);
        cameraTexture.setOnFrameAvailableListener(this);
        Matrix.setIdentityM(mSTMatrix, 0);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        synchronized (this) {
            if (updateSurface) {
                cameraTexture.updateTexImage();
                cameraTexture.getTransformMatrix(mSTMatrix);
                updateSurface = false;
            }
        }
        GLUtil.drawCamera(textureId, mSTMatrix, filterType);
    }

    @Override
    public void onFrameAvailable(SurfaceTexture surfaceTexture) {
        updateSurface = true;
    }
}
