package com.vid2cam.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import java.util.List;

public class FaceDetectionOverlay extends View {
    private List<android.graphics.Rect> faceRects;
    private Paint paint;

    public FaceDetectionOverlay(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint();
        paint.setColor(Color.GREEN);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5);
    }

    public void setFaceRects(List<android.graphics.Rect> rects) {
        this.faceRects = rects;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (faceRects != null) {
            for (android.graphics.Rect rect : faceRects) {
                canvas.drawRect(rect, paint);
            }
        }
    }
}
