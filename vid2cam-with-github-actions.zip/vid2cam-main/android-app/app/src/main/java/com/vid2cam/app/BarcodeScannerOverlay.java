package com.vid2cam.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class BarcodeScannerOverlay extends View {
    private Paint paint;

    public BarcodeScannerOverlay(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint();
        paint.setColor(Color.YELLOW);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(6);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Draw a simple scanning rectangle in the center
        int w = getWidth();
        int h = getHeight();
        int rectW = w * 3 / 4;
        int rectH = h / 4;
        int left = (w - rectW) / 2;
        int top = (h - rectH) / 2;
        int right = left + rectW;
        int bottom = top + rectH;
        canvas.drawRect(left, top, right, bottom, paint);
    }
}
